/* 
 *  Matthew McGilvery
 * 3-6-15
 * #5 (Programming Projects) 
 * Chapter 1 Savitch 9th Edition
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
//Declare variables
    char x; //Character to be used to display X
    //Prompt user to enter x
    cout << "Please input the letter X and hit enter";
    cin >> x;
    //Output Big CS
    cout <<     "      "<<x<<x<<x<<x<<endl;               
    cout <<  "    " <<x<<"           "<<endl;
    cout << "   "<<x<<"            "<<endl;
    cout <<"  "<<x<<"             "<<endl;
    cout <<"  "<<x<<"             "<<endl;
    cout <<"  "<<x<<"             "<<endl;
    cout <<"  "<<x<<"             "<<endl;
    cout <<"  "<<x<<"             "<<endl;
    cout <<"  "<<x<<"                      "<<endl;
    cout << "   "<<x<<"                     "<<endl;
    cout <<  "    " <<x<<"                    "<<endl;
     cout <<     "      "<<x<<x<<x<<x<<endl;
 return 0;  
}
    