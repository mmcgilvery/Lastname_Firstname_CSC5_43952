/* 
 * File:   main.cpp
 * Author: sirchester
 *
 * Created on May 4, 2015, 9:38 AM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

