/* Matthew McGilvery
 * 5 - 4 - 15
 * Chapter 7, of Gaddis 8th Ed, Prob #1
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
#include <iomanip>
#include <ctime>
#include <cstdlib>

using namespace std;
//User Libraries


//Global Constants


//Function Prototypes
//Execution begins here!
int main() {
    unsigned const int SIZE = 6000;
    int array[SIZE];
    for (int j = 0; j < 10; j++){
     cout << "Input a number, separated by the press of the enter key." << endl;
     cin >> array[j];
    }
    
    if (array[0] > array [1]){
        if (array[0] > array [2]){
            if (array[0] > array [3]){
                if (array[0] > array [4]){
                    if (array[0] > array [5]) {
                             if (array[0] > array [6]) {
                                 if (array[0] > array [7]) {
                                     if (array[0] > array [8]) {
                                         if (array[0] > array [9]) {
                                             cout << "Value 1, " << array [0] << " is the maximum value." << endl;
                                         }
                                     }
                                 }
                             }
                         
                    }
                }
            }
        
        }
    }
        
        
    else if (array[1] > array [0]){
        if (array[1] > array [2]){
            if (array[1] > array [3]){
                if (array[1] > array [4]){
                    if (array[1] > array [5]) {
                             if (array[1] > array [6]) {
                                 if (array[1] > array [7]) {
                                     if (array[1] > array [8]) {
                                         if (array[1] > array [9]) {
                                             cout << "Value 2, " << array [1] << " is the maximum value." << endl;
                                         }
                                     }
                                 }
                             }
                         
                    }
                }
            }
        
        }
    }
     
    else if (array[2] > array [0]){
        if (array[2] > array [2]){
            if (array[2] > array [3]){
                if (array[2] > array [4]){
                    if (array[2] > array [5]) {
                             if (array[2] > array [6]) {
                                 if (array[2] > array [7]) {
                                     if (array[2] > array [8]) {
                                         if (array[2] > array [9]) {
                                             cout << "Value 3, " << array [2] << " is the maximum value." << endl;
                                         }
                                     }
                                 }
                             }
                         
                    }
                }
            }
        
        }
    }
     else if (array[3] > array [0]){
        if (array[3] > array [2]){
            if (array[3] > array [3]){
                if (array[3] > array [4]){
                    if (array[3] > array [5]) {
                             if (array[3] > array [6]) {
                                 if (array[3] > array [7]) {
                                     if (array[3] > array [8]) {
                                         if (array[3] > array [9]) {
                                             cout << "Value 4, " << array [3] << " is the maximum value." << endl;
                                         }
                                     }
                                 }
                             }
                         
                    }
                }
            }
        
        }
    }
     else if (array[4] > array [0]){
        if (array[4] > array [2]){
            if (array[4] > array [3]){
                if (array[4] > array [4]){
                    if (array[4] > array [5]) {
                             if (array[4] > array [6]) {
                                 if (array[4] > array [7]) {
                                     if (array[4] > array [8]) {
                                         if (array[4] > array [9]) {
                                             cout << "Value 5, " << array [4] << " is the maximum value." << endl;
                                         }
                                     }
                                 }
                             }
                         
                    }
                }
            }
        
        }
    }
     else if (array[5] > array [0]){
        if (array[5] > array [1]){
            if (array[5] > array [2]){
                if (array[5] > array [3]){
                    if (array[5] > array [4]) {
                             if (array[5] > array [6]) {
                                 if (array[5] > array [7]) {
                                     if (array[5] > array [8]) {
                                         if (array[5] > array [9]) {
                                             cout << "Value 6, " << array [5] << " is the maximum value." << endl;
                                         }
                                     }
                                 }
                             }
                         
                    }
                }
            }
        
        }
    }
     else if (array[6] > array [0]){
        if (array[6] > array [1]){
            if (array[6] > array [2]){
                if (array[6] > array [3]){
                    if (array[6] > array [4]) {
                             if (array[6] > array [5]) {
                                 if (array[6] > array [7]) {
                                     if (array[6] > array [8]) {
                                         if (array[6] > array [9]) {
                                             cout << "Value 7, " << array [6] << " is the maximum value." << endl;
                                         }
                                     }
                                 }
                             }
                         
                    }
                }
            }
        
        }
    }
    else if (array[7] > array [0]){
        if (array[7] > array [1]){
            if (array[7] > array [2]){
                if (array[7] > array [3]){
                    if (array[7] > array [4]) {
                             if (array[7] > array [5]) {
                                 if (array[7] > array [6]) {
                                     if (array[7] > array [8]) {
                                         if (array[7] > array [9]) {
                                             cout << "Value 8, " << array [7] << " is the maximum value." << endl;
                                         }
                                     }
                                 }
                             }
                         
                    }
                }
            }
        
        }
    }
     else if (array[8] > array [0]){
        if (array[8] > array [1]){
            if (array[8] > array [2]){
                if (array[8] > array [3]){
                    if (array[8] > array [4]) {
                             if (array[8] > array [6]) {
                                 if (array[8] > array [7]) {
                                     if (array[8] > array [8]) {
                                         if (array[8] > array [9]) {
                                             cout << "Value 9, " << array [8] << " is the maximum value." << endl;
                                         }
                                     }
                                 }
                             }
                         
                    }
                }
            }
        
        }
    }
     else if (array[9] > array [0]){
        if (array[9] > array [1]){
            if (array[9] > array [2]){
                if (array[9] > array [3]){
                    if (array[9] > array [4]) {
                             if (array[9] > array [5]) {
                                 if (array[9] > array [6]) {
                                     if (array[9] > array [7]) {
                                         if (array[9] > array [8]) {
                                             cout << "Value 9, " << array [8] << " is the maximum value." << endl;
                                         }
                                     }
                                 }
                             }
                         
                    }
                }
            }
        
        }
    }
    

        return 0;
}
